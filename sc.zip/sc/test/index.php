<!DOCTYPE html>
<html>
<head>
    <title>Test Module</title>
</head>
<body>
    <script type="module">
        import { TEST } from './test.js';
        console.log('Test import successful:', TEST);
        alert('Module loading works! Check console.');
    </script>
</body>
</html>