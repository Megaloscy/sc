// test.js
console.log('Test script loaded successfully!');
export const TEST = 'This is a test';